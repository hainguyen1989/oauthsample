'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _HomeOutlined = _interopRequireDefault(require('./lib/icons/HomeOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _HomeOutlined;
  exports.default = _default;
  module.exports = _default;