'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _InsuranceFilled = _interopRequireDefault(require('./lib/icons/InsuranceFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _InsuranceFilled;
  exports.default = _default;
  module.exports = _default;