'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _FileExclamationOutlined = _interopRequireDefault(require('./lib/icons/FileExclamationOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _FileExclamationOutlined;
  exports.default = _default;
  module.exports = _default;