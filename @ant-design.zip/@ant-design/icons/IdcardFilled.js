'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _IdcardFilled = _interopRequireDefault(require('./lib/icons/IdcardFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _IdcardFilled;
  exports.default = _default;
  module.exports = _default;