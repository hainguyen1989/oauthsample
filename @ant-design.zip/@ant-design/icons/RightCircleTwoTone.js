'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _RightCircleTwoTone = _interopRequireDefault(require('./lib/icons/RightCircleTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _RightCircleTwoTone;
  exports.default = _default;
  module.exports = _default;