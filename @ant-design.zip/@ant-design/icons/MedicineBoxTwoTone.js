'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _MedicineBoxTwoTone = _interopRequireDefault(require('./lib/icons/MedicineBoxTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _MedicineBoxTwoTone;
  exports.default = _default;
  module.exports = _default;