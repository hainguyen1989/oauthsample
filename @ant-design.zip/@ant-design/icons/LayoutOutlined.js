'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _LayoutOutlined = _interopRequireDefault(require('./lib/icons/LayoutOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _LayoutOutlined;
  exports.default = _default;
  module.exports = _default;