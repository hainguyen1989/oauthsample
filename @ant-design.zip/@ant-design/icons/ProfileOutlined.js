'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _ProfileOutlined = _interopRequireDefault(require('./lib/icons/ProfileOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _ProfileOutlined;
  exports.default = _default;
  module.exports = _default;