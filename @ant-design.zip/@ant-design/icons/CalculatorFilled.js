'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CalculatorFilled = _interopRequireDefault(require('./lib/icons/CalculatorFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CalculatorFilled;
  exports.default = _default;
  module.exports = _default;