'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _LockOutlined = _interopRequireDefault(require('./lib/icons/LockOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _LockOutlined;
  exports.default = _default;
  module.exports = _default;