'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _TaobaoOutlined = _interopRequireDefault(require('./lib/icons/TaobaoOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _TaobaoOutlined;
  exports.default = _default;
  module.exports = _default;