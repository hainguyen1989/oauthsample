'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _LaptopOutlined = _interopRequireDefault(require('./lib/icons/LaptopOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _LaptopOutlined;
  exports.default = _default;
  module.exports = _default;