'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _LockFilled = _interopRequireDefault(require('./lib/icons/LockFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _LockFilled;
  exports.default = _default;
  module.exports = _default;