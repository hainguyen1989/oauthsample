'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _GiftTwoTone = _interopRequireDefault(require('./lib/icons/GiftTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _GiftTwoTone;
  exports.default = _default;
  module.exports = _default;