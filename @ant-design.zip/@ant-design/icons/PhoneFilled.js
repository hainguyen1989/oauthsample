'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _PhoneFilled = _interopRequireDefault(require('./lib/icons/PhoneFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _PhoneFilled;
  exports.default = _default;
  module.exports = _default;