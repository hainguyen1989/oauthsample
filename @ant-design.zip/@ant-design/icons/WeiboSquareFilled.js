'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _WeiboSquareFilled = _interopRequireDefault(require('./lib/icons/WeiboSquareFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _WeiboSquareFilled;
  exports.default = _default;
  module.exports = _default;