'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BorderInnerOutlined = _interopRequireDefault(require('./lib/icons/BorderInnerOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BorderInnerOutlined;
  exports.default = _default;
  module.exports = _default;