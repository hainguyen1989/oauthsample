'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _SoundTwoTone = _interopRequireDefault(require('./lib/icons/SoundTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _SoundTwoTone;
  exports.default = _default;
  module.exports = _default;