'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _FlagFilled = _interopRequireDefault(require('./lib/icons/FlagFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _FlagFilled;
  exports.default = _default;
  module.exports = _default;