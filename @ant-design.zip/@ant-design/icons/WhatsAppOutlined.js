'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _WhatsAppOutlined = _interopRequireDefault(require('./lib/icons/WhatsAppOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _WhatsAppOutlined;
  exports.default = _default;
  module.exports = _default;