'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _UpSquareFilled = _interopRequireDefault(require('./lib/icons/UpSquareFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _UpSquareFilled;
  exports.default = _default;
  module.exports = _default;