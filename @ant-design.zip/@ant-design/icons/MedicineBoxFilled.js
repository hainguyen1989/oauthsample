'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _MedicineBoxFilled = _interopRequireDefault(require('./lib/icons/MedicineBoxFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _MedicineBoxFilled;
  exports.default = _default;
  module.exports = _default;