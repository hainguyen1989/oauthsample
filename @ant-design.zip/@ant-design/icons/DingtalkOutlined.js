'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _DingtalkOutlined = _interopRequireDefault(require('./lib/icons/DingtalkOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _DingtalkOutlined;
  exports.default = _default;
  module.exports = _default;