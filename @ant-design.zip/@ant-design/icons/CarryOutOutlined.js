'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CarryOutOutlined = _interopRequireDefault(require('./lib/icons/CarryOutOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CarryOutOutlined;
  exports.default = _default;
  module.exports = _default;