'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CopyOutlined = _interopRequireDefault(require('./lib/icons/CopyOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CopyOutlined;
  exports.default = _default;
  module.exports = _default;