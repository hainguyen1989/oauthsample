'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _KeyOutlined = _interopRequireDefault(require('./lib/icons/KeyOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _KeyOutlined;
  exports.default = _default;
  module.exports = _default;