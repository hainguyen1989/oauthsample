'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _FieldStringOutlined = _interopRequireDefault(require('./lib/icons/FieldStringOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _FieldStringOutlined;
  exports.default = _default;
  module.exports = _default;