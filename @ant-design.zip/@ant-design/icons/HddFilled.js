'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _HddFilled = _interopRequireDefault(require('./lib/icons/HddFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _HddFilled;
  exports.default = _default;
  module.exports = _default;