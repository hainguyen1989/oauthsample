'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BoxPlotFilled = _interopRequireDefault(require('./lib/icons/BoxPlotFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BoxPlotFilled;
  exports.default = _default;
  module.exports = _default;