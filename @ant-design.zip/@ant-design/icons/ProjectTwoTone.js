'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _ProjectTwoTone = _interopRequireDefault(require('./lib/icons/ProjectTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _ProjectTwoTone;
  exports.default = _default;
  module.exports = _default;