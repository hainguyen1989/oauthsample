import * as React from 'react';
import { TooltipProps } from '../tooltip';
declare const SliderTooltip: React.ForwardRefExoticComponent<TooltipProps & React.RefAttributes<unknown>>;
export default SliderTooltip;
