export declare type PaginationType = boolean | {
    pageSize?: number;
};
