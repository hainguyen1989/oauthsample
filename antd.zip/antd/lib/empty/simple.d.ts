/// <reference types="react" />
declare const Simple: () => JSX.Element;
export default Simple;
