import Pagination from './Pagination';
export { PaginationProps, PaginationConfig } from './Pagination';
export default Pagination;
