declare const _default: "4.16.0";
export default _default;
