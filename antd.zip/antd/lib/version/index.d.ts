import version from './version';
export default version;
