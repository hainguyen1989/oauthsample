import locale from '../locale/ta_IN';
export default locale;
