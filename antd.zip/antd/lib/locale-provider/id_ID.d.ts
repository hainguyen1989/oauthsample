import locale from '../locale/id_ID';
export default locale;
