import locale from '../locale/nb_NO';
export default locale;
