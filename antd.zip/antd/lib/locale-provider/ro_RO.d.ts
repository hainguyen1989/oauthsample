import locale from '../locale/ro_RO';
export default locale;
