import locale from '../locale/nl_NL';
export default locale;
