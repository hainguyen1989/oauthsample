import locale from '../locale/by_BY';
export default locale;
