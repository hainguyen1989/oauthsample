import locale from '../locale/et_EE';
export default locale;
