import locale from '../locale/uk_UA';
export default locale;
