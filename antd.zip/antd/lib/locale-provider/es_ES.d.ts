import locale from '../locale/es_ES';
export default locale;
