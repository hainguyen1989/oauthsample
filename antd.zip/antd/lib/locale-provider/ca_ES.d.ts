import locale from '../locale/ca_ES';
export default locale;
