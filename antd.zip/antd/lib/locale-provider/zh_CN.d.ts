import locale from '../locale/zh_CN';
export default locale;
