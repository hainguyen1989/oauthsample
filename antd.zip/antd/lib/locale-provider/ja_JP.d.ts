import locale from '../locale/ja_JP';
export default locale;
