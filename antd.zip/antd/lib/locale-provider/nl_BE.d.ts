import locale from '../locale/nl_BE';
export default locale;
