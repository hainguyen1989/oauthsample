import locale from '../locale/tr_TR';
export default locale;
