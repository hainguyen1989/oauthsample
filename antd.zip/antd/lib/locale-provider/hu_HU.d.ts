import locale from '../locale/hu_HU';
export default locale;
