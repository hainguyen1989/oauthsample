import locale from '../locale/gl_ES';
export default locale;
