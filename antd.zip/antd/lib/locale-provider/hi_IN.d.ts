import locale from '../locale/hi_IN';
export default locale;
