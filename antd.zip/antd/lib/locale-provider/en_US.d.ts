import locale from '../locale/en_US';
export default locale;
