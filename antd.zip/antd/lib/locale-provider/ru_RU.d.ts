import locale from '../locale/ru_RU';
export default locale;
