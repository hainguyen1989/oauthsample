import locale from '../locale/da_DK';
export default locale;
