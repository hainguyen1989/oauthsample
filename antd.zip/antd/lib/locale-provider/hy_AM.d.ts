import locale from '../locale/hy_AM';
export default locale;
