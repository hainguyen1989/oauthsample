import locale from '../locale/bg_BG';
export default locale;
