import locale from '../locale/ku_IQ';
export default locale;
