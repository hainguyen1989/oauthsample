import locale from '../locale/pl_PL';
export default locale;
