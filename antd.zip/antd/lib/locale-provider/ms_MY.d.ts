import locale from '../locale/ms_MY';
export default locale;
