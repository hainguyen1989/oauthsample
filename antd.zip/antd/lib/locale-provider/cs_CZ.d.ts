import locale from '../locale/cs_CZ';
export default locale;
