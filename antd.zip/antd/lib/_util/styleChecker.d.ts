export declare const canUseDocElement: () => false | HTMLElement;
export declare const isStyleSupport: (styleName: string | Array<string>) => boolean;
export declare const detectFlexGapSupported: () => boolean;
