import { resetWarned } from 'rc-util/lib/warning';
export { resetWarned };
declare const _default: (valid: boolean, component: string, message: string) => void;
export default _default;
