export default class UnreachableException {
    constructor(value: never);
}
