import { Col, ColProps, ColSize } from '../grid';
export { ColProps, ColSize };
export default Col;
