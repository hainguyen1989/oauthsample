import * as React from 'react';
export interface CardGridProps {
    prefixCls?: string;
    className?: string;
    hoverable?: boolean;
    style?: React.CSSProperties;
}
declare const Grid: React.FC<CardGridProps>;
export default Grid;
