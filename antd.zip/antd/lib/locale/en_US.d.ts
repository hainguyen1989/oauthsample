import defaultLocale from './default';
export default defaultLocale;
