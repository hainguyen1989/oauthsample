import Statistic, { StatisticProps } from './Statistic';
export { StatisticProps };
export default Statistic;
