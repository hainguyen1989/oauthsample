/// <reference types="react" />
import { TagProps } from '../tag';
export default function PickerTag(props: TagProps): JSX.Element;
