/// <reference types="react" />
import { ButtonProps } from '../button';
export default function PickerButton(props: ButtonProps): JSX.Element;
