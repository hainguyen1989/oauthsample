/// <reference types="react" />
declare const Unauthorized: () => JSX.Element;
export default Unauthorized;
