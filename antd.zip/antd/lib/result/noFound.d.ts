/// <reference types="react" />
declare const NoFound: () => JSX.Element;
export default NoFound;
